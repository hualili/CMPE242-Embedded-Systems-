/**************************************************  
 * Program: pwm_testNew.c    Coded by: HL;        * 
 * Date:    Dec 14, 2015;    Version: x01.0;      * 
 * Status:  Debug;                                * 
 * Purpose: To drive Hololu motor driver borad    *
 *          you can use this previousely written  *
 *          program for buzzer to drive motor     *
 *          driver board.                         *  
 ************************************************** 
   Compilation and build: use Makefile 
*/
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PWM_IOCTL_SET_FREQ              1
#define PWM_IOCTL_STOP                  0
#define ESC_KEY         0x1b

/*----------------------Get Char--------------------------*/
static int getch(void)
{
        struct termios oldt,newt;
        int ch;

        if (!isatty(STDIN_FILENO)) {
                fprintf(stderr, "this problem should be run at a terminal\n");
                exit(1);
        }
        // save terminal setting
        if(tcgetattr(STDIN_FILENO, &oldt) < 0) {
                perror("save the terminal setting");
                exit(1);
        }

        // set terminal as need
        newt = oldt;
        newt.c_lflag &= ~( ICANON | ECHO );
        if(tcsetattr(STDIN_FILENO,TCSANOW, &newt) < 0) {
                                                                                            45,1-8        16%



