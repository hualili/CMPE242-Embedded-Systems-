/*
=====================================================================================
 Name        : $ cmpe242_combined_app.c
 Author      : $ D H R U V K A K A D I Y A
 Email	     : $ D H R U V . K A K A D I Y A @ G M A I L . C O M
 Date	     : $ 4/13/2015
 Version     : $ 1.1
 Copyright   : $ CMPE 242 / 2015
 Description : $ Implementation of PID algorithm and taken adc values as difference
======================================================================================
*/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#define Kp 4
#define Kd 0.15
#define Ki 0.42
#define PWM_IOCTL_SET_FREQ		1
#define PWM_IOCTL_STOP			0
#define	ESC_KEY				0x1b

struct Complex
{	double a;        //Real Part
	double b;        //Imaginary Part
}          X[33], U, W, T, Tmp;

static int fd = -1;
static int fd1 = -1;
int arr[100] = {0}, i=0, sample, freq = 1000 ;
float power[33], mean;	
float proportional, integral, integrald, derivative, difference, prevpos, rate, control, pwm, diff_factor = 10;
char answer;

static void close_buzzer(void)
{
	if (fd >= 0) {
		ioctl(fd, PWM_IOCTL_STOP);
		if (ioctl(fd, 2) < 0) {
			perror("ioctl 2:");
		}
		close(fd);  // close dhruv_pwm device
		fd = -1;
	}
	close(fd1); // close dhruv_led device
	fd1 = -1;
}

static void open_buzzer(void)
{
	fd = open("/dev/dhruv_pwm", 0);
	fd1 = open("/dev/dhruv_led", 0);
	if (fd < 0) {
		perror("open dhruv_pwm device");
		exit(1);
	}
	if (fd1 < 0) {
		perror("open dhruv_led device");
		exit(1);
	}
	// any function exit call will stop the buzzer
	atexit(close_buzzer);
}


static void set_buzzer_freq(int freq) {
// this IOCTL command is the key to set frequency
	int ret = ioctl(fd, PWM_IOCTL_SET_FREQ, freq);
	if(ret < 0) {
		perror("set the frequency of the buzzer");
		exit(1);
	}
}

static void stop_buzzer(void)
{
	int ret = ioctl(fd, PWM_IOCTL_STOP);
	if(ret < 0) {
		perror("stop the buzzer");
		exit(1);
	}
	if (ioctl(fd, 2) < 0) {
		perror("ioctl 2:");
	}
}

void FFT(void)
{
	int M = 5;
	int N = pow(2.0, M);
	int i = 1, j = 1, k = 1;
	int LE = 0, LE1 = 0;
	int IP = 0;
	for (k = 1; k <= M; k++)
	{
		LE = pow(2.0, M + 1 - k);
		LE1 = LE / 2;
		U.a = 1.0;
		U.b = 0.0;
		W.a = cos(M_PI / (double)LE1);
		W.b = -sin(M_PI / (double)LE1);
		for (j = 1; j <= LE1; j++)
		{
			for (i = j; i <= N; i = i + LE)
			{
				IP = i + LE1;
				T.a = X[i].a + X[IP].a;
				T.b = X[i].b + X[IP].b;
				Tmp.a = X[i].a - X[IP].a;
				Tmp.b = X[i].b - X[IP].b;
				X[IP].a = (Tmp.a * U.a) - (Tmp.b * U.b);
				X[IP].b = (Tmp.a * U.b) + (Tmp.b * U.a);
				X[i].a = T.a;
				X[i].b = T.b;
			}
			Tmp.a = (U.a * W.a) - (U.b * W.b);
			Tmp.b = (U.a * W.b) + (U.b * W.a);
			U.a = Tmp.a;
			U.b = Tmp.b;
		}
	}
	int NV2 = N / 2;
	int NM1 = N - 1;
	int K = 0;
	j = 1;
	for (i = 1; i <= NM1; i++)
	{
		if (i >= j) goto TAG25;
		T.a = X[j].a;
		T.b = X[j].b;

		X[j].a = X[i].a;
		X[j].b = X[i].b;
		X[i].a = T.a;
		X[i].b = T.b;
TAG25:		K = NV2;
TAG26:		if (K >= j) goto TAG30;
		j = j - K;
		K = K / 2;
		goto TAG26;
TAG30:		j = j + K;
	}
}

static int ADC_FFT(void) {

	int fd = open("/dev/dhruv_adc", 0);
	if (fd < 0) {
		perror("open dhruv_adc device");
		return 1;
	}
	fprintf(stderr, "press Ctrl-C to stop\n");
	
	for(i=0;i<32;i++) {
		char buffer[30];
		int len = read(fd, buffer, sizeof buffer -1);
		if (len > 0) {
			buffer[len] = '\0';
			int value = -1;
			usleep(500000);
			sscanf(buffer, "%d", &value);
			printf("ADC Value: %d\n", value);
			arr[i]=value;
		} else {
			perror("read ADC device:");
			return 1;
		}
		usleep(500* 1000);
	}
	close(fd);
	for (i = 1; i <= 32; i++)
	{
		X[i].a = arr[i];
		X[i].b = 0.0;
	}
	printf ("*********Before*********\n");
	for (i = 1; i <= 32; i++)
		printf ("X[%d]:real == %f  imaginary == %f\n", i-1, X[i].a, X[i].b);
//********************************Implementation of FFT**********************************************************
	FFT();
	for (i = 1; i <= 32; i++)
	{
		X[i].a = X[i].a/32;
		X[i].b = X[i].b/32;
	}
	printf ("\n\n**********After*********\n");
	for (i = 1; i <= 32; i++)
		printf ("X[%d]:real == %f  imaginary == %f\n", i-1, X[i].a, X[i].b);
	for(i=1;i<=32; i++)
	{
		power[i]= sqrt(((X[i].a*X[i].a)+(X[i].b*X[i].b)));
		printf("power spectrum value of power[%d] is = %f \n",i-1,power[i]);
	}
	mean=0;
	for(i=12;i<=19;i++)
	{
		mean= mean+ power[i];
	}
	mean/=8;
	printf("mean is %f \n",mean);

	if(mean<(0.05*power[1]))
		printf("values are valid \n");
	else
		printf("values are not valid \n");
	
	return 0;

}
int main(int argc, char **argv)
{
	ADC_FFT();
	open_buzzer();
	ioctl(fd1, 0, 1);
	pwm = freq ;
	for(i=1;i<=32;i++)
		arr[i-1]=arr[i];
	for(i=0;i<32;i++)		
		arr[i]=arr[i]-511;
TAG1:
	printf("enter the sample number between 0 and 31 \n");
	scanf("%d",&sample);
	if((sample>=0) && (sample<=31))
	{
		if(sample==0)
			difference = arr[sample+1] - arr[sample]; // forward difference
		else if(sample==31)
			difference = arr[sample]-arr[sample-1];	 // backward difference
		else
			difference = (arr[sample+1] - arr[sample -1] )*0.5; // central difference

		difference *= diff_factor ; //diff_factor depends on how large error you want as change in difference

//***************************************Implementation of PID********************************************************
		if(difference != 0)
		{		
			proportional = difference * Kp;
			integral += difference ;
			integrald = integral * Ki;
			rate = prevpos - difference ;
			derivative = rate * Kd;
			control = proportional + integrald + derivative ;
			integral /= 1.3 ;
			pwm -= abs(control) ;

////////////////Code below is only for indication if difference is negative or positive//////////////////////////////
			if(difference<0)
			{
				ioctl(fd1, 1, 1);
			}
			else
			{
				ioctl(fd1, 0, 1);	
			}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		} 	
		prevpos = difference ;
		set_buzzer_freq(pwm);  		// set output according to pid output
		printf(" pwm frequency is %f \n", pwm );
		printf("Do you want to enter another sample to calculate PID ? y/n \n");
		scanf(" %c", &answer);
		if(answer=='y')
		{
			goto TAG1;
		}
		else 
			goto TAGexit;
	}
	else
		goto TAG1;
TAGexit:
	close_buzzer();
	return 0;
}
