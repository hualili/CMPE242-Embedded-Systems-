cd /home/harry/Desktop/SJSU/befor2018/EE264/EE264Ubuntu/OpenCV/OpenCV/opencv-2.4.6.1/samples/c/harry/lecPID/

harry@harry-laptop:~/Desktop/SJSU/befor2018/EE264/EE264Ubuntu/OpenCV/OpenCV/opencv-2.4.6.1/samples/c/harry/lecPID$ 
